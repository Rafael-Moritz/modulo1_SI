#include "cliente.h"

Cliente::Cliente(){
  this->imei   = -1;
  this->login = "";
};  
Cliente::Cliente(int imei, std::string login){
  this->imei    = imei;
  this->login  = login;
}
string Cliente::getNome() const {
  return login;
}
int Cliente::getimei() const{
  return imei;
}